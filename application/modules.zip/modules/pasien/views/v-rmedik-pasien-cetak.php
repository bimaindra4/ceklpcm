<style type="text/css">
    .tgl-cetak {
        display: none;
    }

    @media print {
        div.rowForm {
            display: none;
        }

        .tgl-cetak {
            display: block;
        }
    }
</style>

<div class="page-content">
    <div class="page-head">
        <div class="page-title">
            <h1>Cetak <small>Laporan</small></h1>
        </div>
    </div>
    <ul class="page-breadcrumb breadcrumb">
        <li>
            <a href="#">Pasien</a>
            <i class="fa fa-circle"></i>
        </li>
        <li>
            <span class="active">Cetak Laporan</span>
        </li>
    </ul>

    <div class="rowForm">
        <div class="row">
            <div class="col-md-6">
                <div class="portlet light">
                    <div class="portlet-body">
                        <form class="form-horizontal">
                            <div class="form-body">
                                <div class="form-group">
                                    <label class="control-label col-md-4">Berdasarkan</label>
                                    <div class="col-md-8">
                                        <div class="mt-radio-inline">
                                            <label class="mt-radio">
                                                <input type="radio" name="sort" value="dokter" style="margin-right: 5px" checked> Dokter
                                                <span></span>
                                            </label>
                                            <label class="mt-radio">
                                                <input type="radio" name="sort" value="ruang"> Ruangan
                                                <span></span>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="portlet light bordered">
                <div class="portlet-title">
                    <div class="caption font-dark">
                        <i class="icon-printer font-dark"></i>
                        <span class="caption-subject uppercase"> Cetak Data Rekam Medik </span>
                    </div>
                    <div class="actions">
                        <a class="btn blue btn-xs btn-outline" href="#" onclick="window.print()">
                            <i class="fa fa-print"></i> Cetak
                        </a>
                    </div>
                </div>
                <div class="portlet-body">
                    <table class="table table-striped table-bordered table-hover order-column">
                        <thead>
                            <tr>
                                <th rowspan="2" class="text-center align-middle">No</th>
                                <th rowspan="2" class="text-center align-middle" id="sortBy">Dokter</th>
                                <th rowspan="2" class="text-center align-middle">Total DRM Cek</th>
                                <th rowspan="2" class="text-center align-middle">DRM Lengkap</th>
                                <th rowspan="2" class="text-center align-middle">DRM Tidak Lengkap</th>
                                <th colspan="2" class="text-center align-middle">Presentase</th>
                            </tr>
                            <tr>
                                <th class="text-center align-middle">Lengkap</th>
                                <th class="text-center align-middle">Tidak Lengkap</th>
                            </tr>
                        </thead>
                        <tbody id="resultData">
                            <?php $no=1; foreach($dokter_lap as $row) { ?>
                            <tr class="odd gradeX">
                                <td width="50"><?php echo $no ?></td>
                                <td width="200"><?php echo $row['nama_dokter'] ?></td>
                                <td width="50" class="text-center"><?php echo $row['total_drm'] ?></td>
                                <td width="50" class="text-center"><?php echo $row['drm_lengkap'] ?></td>
                                <td width="50" class="text-center"><?php echo $row['drm_tdk_lengkap'] ?></td>
                                <td width="50" class="text-center"><?php echo $row['persen_lengkap'] ?> %</td>
                                <td width="50" class="text-center"><?php echo $row['persen_tdk_lengkap'] ?> %</td>
                            </tr>
                            <?php $no++; } ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <p class="tgl-cetak">
                Dicetak pada : <?php date_default_timezone_set("Asia/Jakarta"); echo date("d-m-Y H:i:s"); ?>
            </p>
        </div>
    </div>
</div>