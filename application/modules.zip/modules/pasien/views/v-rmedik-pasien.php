<div class="page-content">
    <div class="page-head">
        <div class="page-title">
            <h1>Data <small>Pasien</small></h1>
        </div>
    </div>
    <ul class="page-breadcrumb breadcrumb">
        <li>
            <a href="#">Pasien</a>
            <i class="fa fa-circle"></i>
        </li>
        <li>
            <span class="active">Data Pasien</span>
        </li>
    </ul>

    <div class="row">
        <div class="col-md-12">
            <button data-toggle="modal" data-target="#tambah-pasien" class="btn blue btn-outline" style="margin-bottom: 15px">Tambah Pasien</button>
            <button data-toggle="modal" data-target="#import" class="btn green btn-outline pull-right" style="margin-bottom: 15px">Import Data</button>            
            <div class="portlet light bordered">
                <div class="portlet-title">
                    <div class="caption font-dark">
                        <i class="icon-users font-dark"></i>
                        <span class="caption-subject uppercase"> Data Pasien </span>
                    </div>
                    <div class="actions">
                        <a class="btn btn-circle btn-icon-only btn-default tooltips" data-toggle="modal" data-target="#cari" data-container="body" data-placement="left" data-original-title="Cari No Rekam Medis">
                            <i class="icon-magnifier"></i>
                        </a>
                    </div>
                </div>
                <div class="portlet-body">
                    <table class="table table-striped table-bordered table-hover order-column" id="sample_3">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Tanggal MRS</th>
                                <th>Instalasi/Ruang</th>
                                <th>Dokter</th>
                                <th>Nama Pasien</th>
                                <th>No. RM</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                                date_default_timezone_set("Asia/Jakarta");
                                $no = 1; 
                                foreach($pasien->result() as $row) { 
                                ?>
                                <tr class="odd gradeX">
                                    <td><?php echo $no ?></td>
                                    <td><?php echo date("d M Y", strtotime($row->tanggal_mrs)) ?></td>
                                    <td><?php echo $row->nama_ruang ?></td>
                                    <td><?php echo $row->dpjp ?></td>
                                    <td><?php echo $row->nama_pasien ?></td>
                                    <td><?php echo $row->no_rm ?></td>
                                    <td>
                                        <a href="<?php echo site_url('pasien/edit_form/'.$row->id_pasien) ?>" class="btn blue btn-xs btn-outline">Edit</a>
                                        <a href="<?php echo site_url('pasien/hapus_pasien/'.$row->id_pasien) ?>" class="btn red btn-xs btn-outline">Hapus</a>
                                    </td>
                                </tr>
                            <?php $no++; } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="tambah-pasien" class="modal fade" tabindex="-1" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog">
        <div class="modal-content">
            <?php echo form_open('pasien/tambah_pasien', array('class' => 'form-horizontal')) ?>
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                    <h4 class="modal-title">Tambah Pasien</h4>
                </div>
                <div class="modal-body">
                    <div class="form-body">
                        <div class="form-group">
                            <label class="control-label col-md-3">Nama Pasien</label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" name="nama" autocomplete="off" required="on">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Tanggal MRS</label>
                            <div class="col-md-8">
                                <input class="form-control form-control-inline input-medium date-picker" size="16" type="text" name="tglmrs" autocomplete="off" required="on">
                                <div class="mt-checkbox-list" style="margin-top: 10px; margin-bottom: -20px">
                                    <label class="mt-checkbox">
                                        <input type="checkbox" name="tglskrg" value="1"> Tanggal Sekarang
                                        <span></span>
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">No RM</label>
                            <div class="col-md-8">
                                <input type="number" class="form-control" name="norm" autocomplete="off" required="on">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Instalasi / DPJP</label>
                            <div class="col-md-8">
                                <select class="form-control" name="dpjp" required="on">
                                    <option>-- Pilih Dokter --</option>
                                    <?php foreach($dokter->result() as $row) { ?>
                                        <option value="<?php echo $row->id_dokter ?>"><?php echo $row->nama_dokter ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Dokter 1</label>
                            <div class="col-md-8">
                                <select class="form-control" name="dokter1" required="on">
                                    <option>-- Pilih Dokter --</option>
                                    <?php foreach($dokter->result() as $row) { ?>
                                        <option value="<?php echo $row->id_dokter ?>"><?php echo $row->nama_dokter ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Dokter 2</label>
                            <div class="col-md-8">
                                <select class="form-control" name="dokter2" required="on">
                                    <option>-- Pilih Dokter --</option>
                                    <?php foreach($dokter->result() as $row) { ?>
                                        <option value="<?php echo $row->id_dokter ?>"><?php echo $row->nama_dokter ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Ruang / Instalasi</label>
                            <div class="col-md-8">
                                <select class="form-control" name="ruang" required="on">
                                    <option>-- Pilih R/I --</option>
                                    <?php foreach($ruang_ins->result() as $row) { ?>
                                        <option value="<?php echo $row->id_ruang ?>"><?php echo $row->nama_ruang ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" data-dismiss="modal" class="btn dark btn-outline">Cancel</button>
                    <button type="submit" class="btn green">Submit</button>
                </div>
            <?php echo form_close() ?>
        </div>
    </div>
</div>

<div id="cari" class="modal fade" tabindex="-1" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                <h4 class="modal-title">Cari No Rekam Medis</h4>
            </div>
            <div class="modal-body">
                <?php echo form_open('klpcm/hasil_klpcm') ?>
                    <div class="form-body">
                        <div class="form-group">
                            <label class="control-label">No. Rekam Medis</label>
                            <div class="input-group">
                                <input type="text" class="form-control" name="cari" autocomplete="off" id="nip">
                                <span class="input-group-btn">
                                    <button class="btn blue" type="submit">Cari</button>
                                </span>
                            </div>
                        </div>
                    </div>
                <?php echo form_close() ?>
            </div>
            <div class="modal-footer">
                <button type="button" data-dismiss="modal" class="btn dark btn-outline">Cancel</button>
            </div>
        </div>
    </div>
</div>

<div id="import" class="modal fade" tabindex="-1" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog">
        <?php echo form_open_multipart('pasien/import_pasien', array("class" => "form-control")) ?>
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                    <h4 class="modal-title">Import Data Pasien</h4>
                </div>
                <div class="modal-body">
                    <div class="form-body">
                        <div class="form-group">
                            <label class="control-label">Upload File (.xls)</label>
                            <div class="input-group">
                                <input type="file" name="import">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" data-dismiss="modal" class="btn dark btn-outline">Cancel</button>
                    <button type="submit" class="btn btn-primary">Upload!</button>
                </div>
            </div>
        <?php echo form_close() ?>
    </div>
</div>