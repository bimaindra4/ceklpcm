<?php if (!defined('BASEPATH')) exit('Maaf, akses secara langsung tidak diperkenankan.');
class Pasien extends MX_Controller {
	function __construct() {
    	parent::__construct();
		$this->load->model("App_Model");
		$this->load->model("M_pasien");
    }

    function data() {
		$session = $this->App_Model->get_session();
		if (!$session['session_userid'] && !$session['session_status']){
			redirect('login');
		} else {
			$id_user = $session['session_userid'];
			$status = $session['session_status'];
			if($status == 1) {
				$data['pasien'] = $this->M_pasien->getAllData();
				$data['dokter'] = $this->M_pasien->getAllDokter();
				$data['ruang_ins'] = $this->M_pasien->getAllRuang();
 				$data['namamodule'] = "pasien";
				$data['namafileview'] = "v-rmedik-pasien";
				echo Modules::run('template/rmedik_template', $data);
			} elseif($status == 2) {
				$data['namamodule'] = "beranda";
				$data['namafileview'] = "v-rperawat-dashboard";
				echo Modules::run('template/rperawat_template', $data);	
			} else {
				redirect('login');
			}
		}
    }
    
    function cetak() {
		$session = $this->App_Model->get_session();
		if (!$session['session_userid'] && !$session['session_status']){
			redirect('login');
		} else {
			$id_user = $session['session_userid'];
			$status = $session['session_status'];
			if($status == 1) {
				$data['dokter_lap'] = $this->M_pasien->getDokterLap();
				$data['namamodule'] = "pasien";
				$data['namafileview'] = "v-rmedik-pasien-cetak";
				echo Modules::run('template/rmedik_template', $data);
			} elseif($status == 2) {
				$data['namamodule'] = "beranda";
				$data['namafileview'] = "v-rperawat-dashboard";
				echo Modules::run('template/rperawat_template', $data);	
			} else {
				redirect('login');
			}
		}
	}

	function edit_form($val) {
		$session = $this->App_Model->get_session();
		if (!$session['session_userid'] && !$session['session_status']){
			redirect('login');
		} else {
			$id_user = $session['session_userid'];
			$status = $session['session_status'];
			if($status == 1) {
				$data['pasien'] = $this->M_pasien->getDetailPasien($val);
				$data['dokter'] = $this->M_pasien->getAllDokter();
				$data['ruang_ins'] = $this->M_pasien->getAllRuang();
				$data['namamodule'] = "pasien";
				$data['namafileview'] = "v-rmedik-pasien-edit";
				echo Modules::run('template/rmedik_template', $data);
			} else {
				redirect('login');
			}
		}
	}

	function tambah_pasien() {
		$session = $this->App_Model->get_session();
		if (!$session['session_userid'] && !$session['session_status']){
			redirect('login');
		} else {
			$id_user = $session['session_userid'];
			$status = $session['session_status'];
			if($status == 1) {
				$this->M_pasien->insertRM();
				$this->M_pasien->insertPasien();

				redirect("pasien/data");
			} elseif($status == 2) {

			} else {
				redirect('login');
			}
		}
	}

	function edit_pasien($val) {
		$session = $this->App_Model->get_session();
		if (!$session['session_userid'] && !$session['session_status']){
			redirect('login');
		} else {
			$id_user = $session['session_userid'];
			$status = $session['session_status'];
			if($status == 1) {
				$this->M_pasien->editPasien($val);

				redirect("pasien/data");
			} elseif($status == 2) {

			} else {
				redirect('login');
			}
		}
	}

	function hapus_pasien($val) {
		$session = $this->App_Model->get_session();
		if (!$session['session_userid'] && !$session['session_status']){
			redirect('login');
		} else {
			$id_user = $session['session_userid'];
			$status = $session['session_status'];
			if($status == 1) {
				$this->M_pasien->deletePasien($val);
		
				redirect("pasien/data");
			} elseif($status == 2) {

			} else {
				redirect('login');
			}
		}
	}

	function f_edit_pasien($val) {
		$session = $this->App_Model->get_session();
		if (!$session['session_userid'] && !$session['session_status']){
			redirect('login');
		} else {
			$id_user = $session['session_userid'];
			$status = $session['session_status'];
			if($status == 1) {
				$data['pasien'] = $this->M_pasien->getSelectedData($val);
				$data['namamodule'] = "pasien";
				$data['namafileview'] = "v-rmedik-pasien-edit";
				echo Modules::run('template/rmedik_template', $data);
			} else {
				redirect('login');
			}
		}
	}

	function import_pasien() {
		$session = $this->App_Model->get_session();
		if (!$session['session_userid'] && !$session['session_status']){
			redirect('login');
		} else {
			$id_user = $session['session_userid'];
			$status = $session['session_status'];
			if($status == 1) {
				$config['upload_path'] = './uploads/';
				$config['allowed_types'] = 'xls';
				$config['max_size'] = 10240; // 10 MB
				$this->load->library('upload', $config);

				if(!$this->upload->do_upload('import')) {
					$error = array('error' => $this->upload->display_errors());
				} else {
					$upload_data = $this->upload->data();
					$this->load->library('Excel_reader');

					// File configuration
					$this->excel_reader->setOutputEncoding('230787');
					$file = $upload_data['full_path'];
					$this->excel_reader->read($file);
					error_reporting(E_ALL ^ E_NOTICE);

					// Data
					$data = $this->excel_reader->sheets[0];
					$dataExcel = array();
					for($i=2; $i<=$data['numRows']; $i++) {
						if($data['cells'][$i][1] == '') {
							break;
						}

						$dataExcel[$i-2]['nama_pasien'] = $data['cells'][$i][2];
						$dataExcel[$i-2]['tggl_mrs'] = $data['cells'][$i][3];
						$dataExcel[$i-2]['no_rm'] = $data['cells'][$i][4];
						$dataExcel[$i-2]['instalasi'] = $data['cells'][$i][5];
						$dataExcel[$i-2]['dokter1'] = $data['cells'][$i][6];
						$dataExcel[$i-2]['dokter2'] = $data['cells'][$i][7];
					}

					$this->M_pasien->generateData($dataExcel);

					// Delete file
					$file = $upload_data['file_name'];
					$path = './uploads/'.$file;
					unlink($path);
				}

				redirect("pasien/data");
			} else {
				redirect('login');
			}
		}
	}

	function showData() {
		$sort = $this->input->post('sortData'); 
	    echo $sort;

	    if($sort == "dokter") {
	    	$data = $this->M_pasien->getDokterLap();
	    	$no = 1;

	    	foreach($data as $row) {
	    		echo '
		            <tr class="odd gradeX">
		                <td width="50">'.$no.'</td>
		                <td width="200">'.$row['nama_dokter'].'</td>
		                <td width="50" class="text-center">'.$row['total_drm'].'</td>
		                <td width="50" class="text-center">'.$row['drm_lengkap'].'</td>
		                <td width="50" class="text-center">'.$row['drm_tdk_lengkap'].'</td>
		                <td width="50" class="text-center">'.$row['persen_lengkap'].' %</td>
		                <td width="50" class="text-center">'.$row['persen_tdk_lengkap'].' %</td>
		            </tr>';

	        	$no++;
	    	}
	    } else if($sort == "ruang") {
	    	$data = $this->M_pasien->getRuangLap();
	    	$no = 1;

	    	foreach($data as $row) {
	    		echo '
		            <tr class="odd gradeX">
		                <td width="50">'.$no.'</td>
		                <td width="200">'.$row['nama_ruang'].'</td>
		                <td width="50" class="text-center">'.$row['total_drm'].'</td>
		                <td width="50" class="text-center">'.$row['drm_lengkap'].'</td>
		                <td width="50" class="text-center">'.$row['drm_tdk_lengkap'].'</td>
		                <td width="50" class="text-center">'.$row['persen_lengkap'].' %</td>
		                <td width="50" class="text-center">'.$row['persen_tdk_lengkap'].' %</td>
		            </tr>';

	        	$no++;
	    	}
	    }

	    /*$no = 1;
	    foreach ($data as $row) {
	        echo '
	            <tr class="odd gradeX">
	                <td width="50">'.$no.'</td>
	                <td width="200">'.$row['nama_dokter'].'</td>
	                <td width="50" class="text-center">'.$row['total_drm'].'</td>
	                <td width="50" class="text-center">'.$row['drm_lengkap'].'</td>
	                <td width="50" class="text-center">'.$row['drm_tdk_lengkap'].'</td>
	                <td width="50" class="text-center">'.$row['persen_lengkap'].' %</td>
	                <td width="50" class="text-center">'.$row['persen_tdk_lengkap'].' %</td>
	            </tr>';

	        $no++;
	    }*/
	}
}
?>