<?php if (!defined('BASEPATH')) exit('Maaf, akses secara langsung tidak diperkenankan.');
class M_pasien extends CI_Model {
	public function __construct() {
		parent::__construct();
    }
    
    function getAllData() {
        $this->db->select("p.tanggal_mrs, r.nama_ruang, d.nama_dokter AS dpjp, p.nama_pasien, p.no_rm, p.id_pasien");
        $this->db->from("pasien p");
        $this->db->join("rekam_medis rm", "p.no_rm = rm.no_rm");
        $this->db->join("dokter d", "rm.instalasi_dpjp = d.id_dokter");
        $this->db->join("ruang r", "rm.id_ruang = r.id_ruang");
        $this->db->order_by("p.tanggal_mrs", "desc");
        $db = $this->db->get();
        return $db;
    }

    function getSelectedData($val) {
        $this->db->where("id_pasien", $val);
        $db = $this->db->get("pasien");
        return $db;
    }

    function getDetailPasien($val) {
        $db = $this->db->query("SELECT p.*, d.nama_dokter AS dpjp, rm.dokter_1 , rm.dokter_2, rm.id_ruang FROM pasien p
                                JOIN rekam_medis rm ON p.no_rm = rm.no_rm
                                JOIN dokter d ON rm.instalasi_dpjp = d.id_dokter
                                WHERE p.id_pasien='$val'");
        return $db->row();
    }

    function getAllDokter() {
        $db = $this->db->get("dokter");
        return $db;
    }

    function getAllRuang() {
        $db = $this->db->get("ruang");
        return $db;
    }

    function getDokterLap($sort="") {
        $l = "L";
        $tl = "TL";
        $dat = [];

        $this->db->select("d.id_dokter, d.nama_dokter, COUNT(rm.no_rm) AS total_drm");
        $this->db->from("rekam_medis rm");
        $this->db->join("dokter d", "rm.instalasi_dpjp = d.id_dokter", "right");
        $this->db->group_by("d.id_dokter");
        $this->db->order_by("d.id_dokter");
        $db = $this->db->get();

        foreach($db->result() as $row) {
             // Hitung DRM Lengkap
            $this->db->select("
                (SELECT COUNT(*) FROM rekam_medis WHERE identitas='$l' AND instalasi_dpjp=$row->id_dokter)+
                (SELECT COUNT(*) FROM rekam_medis WHERE otentifikasi='$l' AND instalasi_dpjp=$row->id_dokter)+
                (SELECT COUNT(*) FROM rekam_medis WHERE lap_penting='$l' AND instalasi_dpjp=$row->id_dokter)+
                (SELECT COUNT(*) FROM rekam_medis WHERE pencatatan='$l' AND instalasi_dpjp=$row->id_dokter) AS lengkap
            ");
            $this->db->from("rekam_medis");
            $drm_lkp = $this->db->get()->row()->lengkap;

            // Hitung DRM Tidak Lengkap
            $this->db->select("
                (SELECT COUNT(*) FROM rekam_medis WHERE identitas='$tl' AND instalasi_dpjp=$row->id_dokter)+
                (SELECT COUNT(*) FROM rekam_medis WHERE otentifikasi='$tl' AND instalasi_dpjp=$row->id_dokter)+
                (SELECT COUNT(*) FROM rekam_medis WHERE lap_penting='$tl' AND instalasi_dpjp=$row->id_dokter)+
                (SELECT COUNT(*) FROM rekam_medis WHERE pencatatan='$tl' AND instalasi_dpjp=$row->id_dokter) AS tdklengkap
            ");
            $this->db->from("rekam_medis");
            $drm_tlkp = $this->db->get()->row()->tdklengkap;

            // Persentase
            if($drm_lkp == 0 && $drm_tlkp == 0) {
                $total_drm = 0;
                $p_lkp = "0";
                $p_tlkp = "0";
            } else {
                $total_drm = $drm_lkp + $drm_tlkp;
                $p_lkp = round(($drm_lkp * 100) / $total_drm, 2); // presentas drm lengkap
                $p_tlkp =  round(($drm_tlkp * 100) / $total_drm, 2); // presentas drm lengkap
            }
                

            $data = [
                "nama_dokter" => $row->nama_dokter,
                "total_drm" => 4*$row->total_drm,
                "drm_lengkap" => $drm_lkp,
                "drm_tdk_lengkap" => $drm_tlkp,
                "persen_lengkap" => $p_lkp,
                "persen_tdk_lengkap" => $p_tlkp
            ];

            array_push($dat, $data);
        }

        return $dat;
    }

    function getRuangLap($sort="") {
        $l = "L";
        $tl = "TL";
        $dat = [];

        $this->db->select("rm.id_ruang, r.nama_ruang, COUNT(rm.no_rm) AS total_drm");
        $this->db->join("ruang r", "rm.id_ruang = r.id_ruang");
        $this->db->group_by("r.id_ruang");
        $this->db->order_by("r.id_ruang");
        $db = $this->db->get('rekam_medis rm');

        foreach($db->result() as $row) {
             // Hitung DRM Lengkap
            $this->db->select("
                (SELECT COUNT(*) FROM rekam_medis WHERE identitas='$l' AND id_ruang=$row->id_ruang)+
                (SELECT COUNT(*) FROM rekam_medis WHERE otentifikasi='$l' AND id_ruang=$row->id_ruang)+
                (SELECT COUNT(*) FROM rekam_medis WHERE lap_penting='$l' AND id_ruang=$row->id_ruang)+
                (SELECT COUNT(*) FROM rekam_medis WHERE pencatatan='$l' AND id_ruang=$row->id_ruang) AS lengkap
            ");
            $this->db->from("rekam_medis");
            $drm_lkp = $this->db->get()->row()->lengkap;

            // Hitung DRM Tidak Lengkap
            $this->db->select("
                (SELECT COUNT(*) FROM rekam_medis WHERE identitas='$tl' AND id_ruang=$row->id_ruang)+
                (SELECT COUNT(*) FROM rekam_medis WHERE otentifikasi='$tl' AND id_ruang=$row->id_ruang)+
                (SELECT COUNT(*) FROM rekam_medis WHERE lap_penting='$tl' AND id_ruang=$row->id_ruang)+
                (SELECT COUNT(*) FROM rekam_medis WHERE pencatatan='$tl' AND id_ruang=$row->id_ruang) AS tdklengkap
            ");
            $this->db->from("rekam_medis");
            $drm_tlkp = $this->db->get()->row()->tdklengkap;

            // Persentase
            if($drm_lkp == 0 && $drm_tlkp == 0) {
                $total_drm = 0;
                $p_lkp = "0";
                $p_tlkp = "0";
            } else {
                $total_drm = $drm_lkp + $drm_tlkp;
                $p_lkp = round(($drm_lkp * 100) / $total_drm, 2); // presentas drm lengkap
                $p_tlkp =  round(($drm_tlkp * 100) / $total_drm, 2); // presentas drm lengkap
            }
                

            $data = [
                "nama_ruang" => $row->nama_ruang,
                "total_drm" => 4*$row->total_drm,
                "drm_lengkap" => $drm_lkp,
                "drm_tdk_lengkap" => $drm_tlkp,
                "persen_lengkap" => $p_lkp,
                "persen_tdk_lengkap" => $p_tlkp
            ];

            array_push($dat, $data);
        }

        return $dat;
    }

    function insertPasien() {
        // Set timezone
        date_default_timezone_set("Asia/Jakarta");
        
        $norm = $this->input->post("norm");

        // create tgl_mrs
		if($this->input->post("tglskrg") == NULL) {
			$tgl_mrs = date("Y-m-d", strtotime($this->input->post("tglmrs")));
		} else {
			$tgl_mrs = date("Y-m-d");
		}

		// insert to pasien
		$data = array(
			"id_pasien" => $id,
			"nama_pasien" => strtoupper($this->input->post("nama")),
			"tanggal_mrs" => $tgl_mrs,
			"no_rm" => $norm
        );
        
        $db = $this->db->insert("pasien", $data);
        ($db) ? $out=true : $out=false;
        return $out;
    }

    function insertRM() {
        // create dokter_1 & dokter_2
		($this->input->post("dokter1") != NULL) ? $d1 = $this->input->post("dokter1") : $d1 = NULL;
		($this->input->post("dokter2") != NULL) ? $d2 = $this->input->post("dokter2") : $d2 = NULL;

		// insert to rekam_medik
		$data = array(
			"no_rm" => $this->input->post("norm"),
			"instalasi_dpjp" => $this->input->post("dpjp"),
			"dokter_1" => $d1,
			"dokter_2" => $d2,
            "id_ruang" => $this->input->post("ruang"),
			"identitas" => NULL,
			"otentifikasi" => NULL,
			"lap_penting" => NULL,
			"pencatatan" => NULL
        );
        
        $db = $this->db->insert("rekam_medis", $data);
        ($db) ? $out=true : $out=false;
        return $out;
    }
    
    function editPasien($val) {
        // Set timezone
        date_default_timezone_set("Asia/Jakarta");
        $date = date("Y-m-d", strtotime($this->input->post("tglmrs")));

        $dat1 = array(
            "nama_pasien" => $this->input->post("nama"),
            "tanggal_mrs" => $date
        );

        $this->db->update("pasien", $dat1, array("id_pasien" => $val));

        ($this->input->post("dokter1") == "") ? $d1 = NULL : $d1 = $this->input->post("dokter1");
        ($this->input->post("dokter2") == "") ? $d2 = NULL : $d2 = $this->input->post("dokter2");

        $dat2 = array(
            "dokter_1" => $d1,
            "dokter_2" => $d2,
            "id_ruang" => $this->input->post('ruang')
        );

        $this->db->update("rekam_medis", $dat2, array("no_rm" => $this->input->post("no_rm")));
    }

    function deletePasien($val) {
        // $val = id_pasien
        // get no_rm from pasien
        $this->db->select("no_rm");
        $this->db->from("pasien");
        $this->db->where("id_pasien", $val);
        $getId = $this->db->get()->row();
        $no_rm = $getId->no_rm;

        // delete pasien
        $this->db->delete("pasien", array("id_pasien" => $val));

        // delete rekam_medis
        $this->db->delete("rekam_medis", array("no_rm" => $no_rm));
    }

    function generateData($val) {
        // Set timezone
        date_default_timezone_set("Asia/Jakarta");

        for($i=0; $i<count($val); $i++) {
            // create dokter_1 & dokter_2
            ($val[$i]['dokter1'] == "-") ? $d1 = NULL : $d1 = $val[$i]['dokter1'];
            ($val[$i]['dokter2'] == "-") ? $d2 = NULL : $d2 = $val[$i]['dokter2'];

            $dpjp = $this->getIDDokter($val[$i]['instalasi']);
            $d1 = $this->getIDDokter($d1);
            $d2 = $this->getIDDokter($d2);

            // insert to rekam_medik
            $dat1 = array(
                "no_rm" => $val[$i]['no_rm'],
                "instalasi_dpjp" => $dpjp,
                "dokter_1" => $d1,
                "dokter_2" => $d2,
                "identitas" => NULL,
                "otentifikasi" => NULL,
                "lap_penting" => NULL,
                "pencatatan" => NULL
            );
            
            $this->db->insert("rekam_medis", $dat1);

            // insert to pasien
            $dat2 = array(
                "id_pasien" => '',
                "nama_pasien" => strtoupper($val[$i]['nama_pasien']),
                "tanggal_mrs" => date("Y-m-d", strtotime($val[$i]['tggl_mrs'])),
                "no_rm" => $val[$i]['no_rm']
            );

            //var_dump($d1);
            
            $db = $this->db->insert("pasien", $dat2);
        }
    }

    function getIDDokter($nama) {
        $this->db->select("id_dokter");
        $this->db->where("nama_dokter", $nama);
        $db = $this->db->get("dokter");

        if($db->num_rows == 0) {
            return NULL;
        } else {
            $res = $db->row();
            return $res->id_dokter;
        }
    }
}
?>